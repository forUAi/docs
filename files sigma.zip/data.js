// Catalogue, archetypes, agents and the deck baseline. Sample data: replace with your API.
var ST = {
  TBD: { label: "Pending", long: "Nobody has answered this yet. Missing evidence is not a confirmed gap." },
  G: { label: "Gap", long: "A technical control still has to be implemented." },
  G3P: { label: "Vendor gap", long: "The shortfall sits in the SaaS or vendor product." },
  C: { label: "Control in place", long: "A technical control is in place for this scope." },
  C3P: { label: "Vendor control in place", long: "A third party provides the control." },
  N: { label: "Not applicable", long: "Does not apply to this scope. A reason must be on record." },
  P: { label: "Partial control", long: "Part of the scope is covered and part is not." },
  GE: { label: "Gap exception", long: "A gap exception has been established. It needs its reference and expiry." },
  G3PG: { label: "Process Unity gap", long: "A third-party gap tracked in Process Unity." },
};
var GAPS = { G: 1, G3P: 1, P: 1, GE: 1, G3PG: 1 };
var DISC = [
  {
    k: "ASSET",
    name: "Asset management",
    team: "Asset Management team",
    reqs: [
      "Discover and aggregate|Discovery source, covered platforms and environments, and reconciliation evidence.",
      "Integrate onboarding process|Registration and onboarding workflow, required fields and the approval handoff.",
      "Lifecycle, creation to decommission|Creation, change, retirement and decommission records.",
      "Accuracy of metadata|Quality of identity, owner, environment and registration fields.",
      "Shadow AI control|Discovered inventory compared with registered inventory, with coverage limits.",
      "Democratize inventory data|Who can access inventory and how that access is governed.",
      "Metrics and reporting|Inventory and control metrics, their definitions, owners and reporting period.",
    ],
  },
  {
    k: "IAM",
    name: "Identity and access",
    team: "Identity and Access team",
    reqs: [
      "Human oversight and approval|Actions that require a person, how approval is enforced, and evidence.",
      "SSO and MFA for owners|Owner identity integration, SSO and MFA configuration.",
      "IdP integration|Identity provider integration and the scope it supports.",
      "Principle of least privilege|Permitted resources and actions, and the least-privilege review.",
      "Strong authentication|Authentication mechanisms for the relevant principals.",
      "Delegation of authority|The delegation chain, the authority permitted and its limits.",
      "Fine-grained authorization|Action-level authorization rules and proof they are enforced.",
      "Context-based authorization|Context conditions used in authorization and how they are enforced.",
      "Resource-level access control|Resource boundaries and access-policy evidence.",
      "Auditing delegated credentials|The audit trail for delegated credentials and their use.",
      "Track delegated actions|Links from the original actor to the delegated identity, action and outcome.",
      "Token activity monitoring|Token activity logs, monitoring coverage and alert evidence.",
      "Credential lifecycle management|Issuance, rotation, revocation and expiry of credentials.",
      "Secrets management|Where secrets are stored, who can reach them, and rotation evidence.",
      "Token exchange|Token exchange flows with audience and scope restrictions.",
      "Mutual authentication|Mutual authentication between communicating parties.",
      "Agent-to-agent authorization|What one agent may ask of another, and how that is enforced.",
    ],
  },
  {
    k: "NET",
    name: "Network security",
    team: "Network Security team",
    reqs: [
      "Internet perimeter enforcement|Applicable internet boundary controls and evidence.",
      "Campus perimeter enforcement|Applicable campus boundary controls and evidence.",
      "Transaction perimeter enforcement|Applicable transaction boundary controls and evidence.",
      "Third-party perimeter enforcement|Third-party boundary and traffic controls.",
      "Segmentation, private data center|Private data-center segmentation and isolation evidence.",
      "Segmentation, public cloud|Public-cloud segmentation and isolation evidence.",
      "Public cloud configuration guardrails|Cloud network guardrail configuration and enforcement.",
      "Public cloud misconfiguration remediation|Detection and remediation of cloud network misconfiguration.",
      "Network threat detection|Network threat monitoring coverage and response evidence.",
      "DDoS protection|Whether DDoS protection applies, and its coverage.",
      "Web application firewall|WAF applicability, configuration and scope.",
      "Unauthorized bot protection|Bot protection applicability and enforcement.",
      "OFAC IP blocking|Whether the IP-blocking requirement applies, with evidence.",
      "Dataflow access for application proxies|Application proxy dataflow permissions and configuration.",
      "User web proxy and content filtering|Web proxy and content-filtering applicability and configuration.",
      "Agent-to-agent secure communication|Protected agent communication paths and trust boundaries.",
    ],
  },
  {
    k: "DATA",
    name: "Data security",
    team: "Data Security team",
    reqs: [
      "Data at rest|Protection of stored data and the scope it covers.",
      "Data in transit|Protection of data in transit across the relevant connections.",
      "Sensitive data loss prevention|Sensitive-data handling, DLP scope and evidence.",
      "Encryption key management|Key ownership, management responsibilities and supported capabilities.",
      "Model training with AXP data|Whether AXP data is used for training, with configuration or agreement evidence.",
      "Training data poisoning|Training-input integrity and poisoning protections where they apply.",
      "Agent memory security|Agent memory storage, isolation, access and retention.",
    ],
  },
  {
    k: "OPS",
    name: "Security operations",
    team: "Security Operations team",
    reqs: [
      "Kill switch|Required stop scope and level, who may activate it, and test evidence.",
      "User consequence management|Insider-risk and user-consequence process and applicable controls.",
      "Agent red teaming|Agent-focused adversarial testing, findings and remediation.",
      "Model red team|Model testing scope, results and unresolved issues.",
      "Audit logging|Logged identities, actions, resources and outcomes, and monitoring coverage.",
      "Agent anomaly detection|Anomaly-detection coverage, rules and validation evidence.",
      "Content moderation|Content moderation scope, configuration and test evidence.",
      "Prompt injection|Prompt-injection safeguards, scope, test results and limitations.",
      "Token usage rate limiting|Token and rate limits, enforcement and alerting.",
    ],
  },
  {
    k: "ARCH",
    name: "Security architecture",
    team: "Security Architecture team",
    reqs: [
      "Secrets redaction in code|Secret detection and redaction scope, and verification.",
      "PII redaction in code|PII redaction scope, configuration and verification.",
      "SDE redaction in code|Programme-defined SDE redaction scope and verification.",
      "Agentic protocol security|Agentic protocol controls and validated tool and communication boundaries.",
      "Agent governance|Accountability, registration, policy and agent-lifecycle governance.",
    ],
  },
];
var REQS = [],
  RIDX = {};
DISC.forEach(function (dd, di) {
  dd.reqs.forEach(function (r, i) {
    var p = r.split("|"),
      id = dd.k + "-" + (i + 1 < 10 ? "0" : "") + (i + 1);
    RIDX[id] = REQS.length;
    REQS.push({ id: id, name: p[0], guide: p[1], di: di });
  });
});
function X(str) {
  var out = [];
  str.split(/\s+/).forEach(function (tk) {
    if (!tk || tk === "|") {
      return;
    }
    var m = tk.split("*"),
      n = m[1] ? parseInt(m[1], 10) : 1,
      c = m[0] === "T" ? "TBD" : m[0];
    for (var i = 0; i < n; i++) {
      out.push(c);
    }
  });
  while (out.length < 61) {
    out.push("TBD");
  }
  return out.slice(0, 61);
}
function joinList(a) {
  return a.length < 2 ? a.join("") : a.slice(0, -1).join(", ") + " and " + a[a.length - 1];
}
function fmt(n) {
  return n.toLocaleString("en-US");
}
var ARCH = {
  coding: {
    name: "Coding agents",
    key: /\bcod(e|ing)\b/,
    deck: "Agent Coding Generation & Executions",
    slides: "8 and 9",
    ks: "level 1",
    does: "Writes or runs code when a developer asks, from an IDE, a CLI or other local software.",
    icon: "M7 6l-4 4 4 4M13 6l4 4-4 4",
  },
  insights: {
    name: "Insights agents",
    key: /insight/,
    deck: "Insights Agent",
    slides: "12",
    ks: "level 1",
    does: "Reads enterprise data to give conclusions, recommendations or explanations. May call APIs to act.",
    icon: "M4 16v-5M10 16V4M16 16V8",
  },
  workflow: {
    name: "Agentic workflows",
    key: /workflow/,
    deck: "Agentic Workflows",
    slides: "15",
    ks: "level 2",
    does: "Carries out a sequence of actions that a user requested or an owner assigned in advance.",
    icon: "M3 4h6v4H3zM11 12h6v4h-6zM6 8v6h5",
  },
  runtime: {
    name: "Platforms and runtimes",
    key: /runtime|platform/,
    deck: "Agent Platform / Runtime",
    slides: "18",
    ks: "level 2",
    does: "The hosting and orchestration layer other agents run on. Controls are shared with the provider.",
    icon: "M10 3l7 4-7 4-7-4zM3 11l7 4 7-4",
  },
  conversational: {
    name: "Conversational agents",
    key: /conversational|chatbot/,
    deck: "Conversational Agents",
    slides: "21 and 22",
    ks: "level 2",
    does: "Talks with people in natural language to give information or carry out tasks.",
    icon: "M3.5 5.5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H9l-3.5 3v-3a2 2 0 0 1-2-2z",
  },
  multi: {
    name: "Multi-agent workflows",
    key: /multi/,
    deck: "Multi-agent Workflows",
    slides: "25",
    ks: "level 3",
    does: "Several specialised agents collaborate, hand each other tasks and pass information along.",
    icon: "M10 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM5 13a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM15 13a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM9 7l-3 6M11 7l3 6M7 15h6",
  },
  native: {
    name: "Native connectors",
    key: /native/,
    deck: "Native Connectors",
    slides: "28",
    ks: "level 2",
    does: "Connectors the platform itself provides, extending an approved AI platform to enterprise data.",
    icon: "M7 3v4M13 3v4M5 7h10v3a5 5 0 0 1-10 0zM10 15v3",
  },
  custom: {
    name: "Custom connectors",
    key: /custom/,
    deck: "Custom Connector",
    slides: "31",
    ks: "level 2",
    does: "Integrations the organisation built itself to connect an approved AI platform to enterprise systems.",
    icon: "M8 12l4-4M6.5 10.5L5 12a2.5 2.5 0 0 0 3.5 3.5L10 14M13.5 9.5L15 8a2.5 2.5 0 0 0-3.5-3.5L10 6",
  },
  backend: {
    name: "Backend agents",
    key: /backend/,
    deck: "Backend Agent",
    slides: "34",
    ks: "level 3",
    does: "Agents that run as backend services with their own identities, without a person in the conversation.",
    icon: "M4 4h12v5H4zM4 11h12v5H4zM7 6.5h.01M7 13.5h.01",
  },
};
var SHORT = {
  coding: "Coding",
  insights: "Insights",
  workflow: "Workflow",
  runtime: "Platform / runtime",
  conversational: "Conversational",
  multi: "Multi-agent",
  native: "Native connector",
  custom: "Custom connector",
  backend: "Backend",
};
var AORDER = ["coding", "insights", "workflow", "runtime", "conversational", "multi", "native", "custom", "backend"];
var ALLICON = "M4 4h5v5H4zM11 4h5v5h-5zM4 11h5v5H4zM11 11h5v5h-5z";
var IAMC = "C C N C N*13",
  NETA = "C C N N C*5 N*4 C C N",
  NETB = "C C N C C*5 N*4 C C N",
  NETF = "C C N C C C C C C C3P C3P C3P N C C N";
var DATC = "C3P*6 G",
  DATD = "C3P*3 G3P C3P C3P G",
  ARC = "C3P*3 P N",
  T61 = "T*61",
  P60 = "P T*60";
var FRI = "C C G C T N G N G N N N G G N N N",
  CCI = "C C C C T C C T C T T T C C C N T",
  CCR = " | T*16 | C*5 T T | C C T T C C C C T | C T T C C";
var EXTW = "T*7 | T*17 | T*16 | T*7 | P P C T C G C C P | N N N C P";
var DECK = " (deck assumption)";
var AGENTS = [
  {
    id: "cursor",
    name: "Cursor",
    does: "AI code editor. Developers ask it to write and change code inside their IDE.",
    as: [["coding", "P G*6 | " + IAMC + " | " + NETA + " | " + DATC + " | C C G C C G P P G | " + ARC]],
  },
  {
    id: "codex",
    name: "Codex",
    does: "OpenAI coding agent. Writes and runs code from a CLI or IDE on a developer's request.",
    as: [["coding", "G*7 | " + IAMC + " | " + NETA + " | " + DATC + " | P C G C C G P P G | " + ARC]],
  },
  {
    id: "claudecode",
    name: "Claude Code",
    does: "Anthropic coding agent for the terminal. Edits files and runs commands when a developer asks.",
    as: [["coding", "P G*6 | " + IAMC + " | " + NETA + " | " + DATC + " | P C G C C G P P G | " + ARC]],
  },
  {
    id: "devin",
    name: "Cog Devin",
    does: "Cognition's Devin. Plans, writes and tests code with more autonomy than an editor assistant.",
    as: [["coding", "G*7 | C C N C N*8 C3P C3P N*3 | " + NETB + " | " + DATD + " | G G G C C G P P G | " + ARC]],
  },
  {
    id: "cc1p",
    name: "Claude Code 1P",
    does: "Claude Code used through Anthropic's own first-party service.",
    as: [["coding", "G*7 | " + IAMC + " | " + NETA + " | " + DATD + " | P P G C C G P P G | " + ARC]],
  },
  {
    id: "copilot",
    name: "GitHub Copilot",
    does: "Code suggestions and chat inside the editor, from GitHub.",
    as: [["coding", "G*7 | " + IAMC + " | " + NETB + " | " + DATD + " | G G G P C G P P G | " + ARC]],
  },
  {
    id: "frontier",
    name: "OpenAI Frontier",
    does: "OpenAI's enterprise agent platform. Used here to write code, run workflows and coordinate several agents.",
    as: [
      ["coding", "G*7 | " + FRI + " | " + NETF + " | C3P*7 | C N C C C C C C3P N | G G G C G"],
      ["workflow", "G*7 | " + FRI + " | " + NETF + " | T*7 | C N C C C C C C3P N | T T T C G"],
      ["multi", T61],
    ],
  },
  {
    id: "prophet",
    name: "Prophet",
    host: "Third-party hosted" + DECK,
    does: "Third-party hosted insights tool. Turns enterprise data into conclusions and recommendations.",
    as: [
      [
        "insights",
        "G*7 | C C C3P C C3P N*7 C3P C3P N*3 | C N N C C C C C C N N N N C C N | C3P C3P N C3P C3P G G | P G G G P G G G N | G G G G P",
      ],
    ],
  },
  {
    id: "elastic",
    name: "Elastic",
    host: "On premises" + DECK,
    does: "Elastic's AI assistant, hosted on premises. Answers questions over search and log data.",
    as: [
      [
        "insights",
        "G*7 | C C G3P C G3P N C N C N C N G3P G3P C N N | C C N C C N N N C N N N N C C N | N C3P P N C3P G G | C G G G P G P P P | P P P C P",
      ],
    ],
  },
  {
    id: "legion",
    name: "Legion",
    does: "Insights agent. Reads enterprise data to explain and recommend.",
    as: [
      [
        "insights",
        "G*7 | C C N C C N C N C N N N C3P C3P N N N | C C N C C N N N C N N N N C N N | C3P C3P G G3P N G G | P G G G P G G G N | G G G G P",
      ],
    ],
  },
  {
    id: "mspp",
    name: "Microsoft Power Platform",
    does: "Copilots and low-code agents that business teams build on Power Platform.",
    as: [["insights", "P T*6 | T*17 | T*16 | T T G T T G N | G*8 T | G G G G P"]],
  },
  {
    id: "nucleus",
    name: "Nucleus",
    does: "Insights agent. Uses AXP data to produce conclusions and recommendations.",
    as: [["insights", "G*7 | C T C C T*13 | T T T C T*12 | T T G T T G G | G*8 P | G G G G P"]],
  },
  {
    id: "decagon",
    name: "Decagon",
    host: "Third-party hosted" + DECK,
    does: "Third-party hosted support agent. Resolves customer requests by taking actions through APIs.",
    as: [
      [
        "workflow",
        "G*7 | C*5 N*7 C3P C3P N*3 | C N N T C N N N C N N N N C N N | G3P C3P C3P G3P C3P C3P C3P | G T T T C3P C3P T T T | G T T T N",
      ],
    ],
  },
  {
    id: "ace",
    name: "Ace Studio",
    ext: true,
    host: "On premises" + DECK,
    does: "On-premises workflow agent. Carries out assigned tasks through APIs.",
    as: [["workflow", T61]],
  },
  {
    id: "dining",
    name: "Dining Agent",
    ext: true,
    does: "Finds and books dining on behalf of external clients.",
    as: [["workflow", EXTW]],
  },
  {
    id: "travel",
    name: "Travel Agent",
    ext: true,
    does: "Plans and books travel on behalf of external clients.",
    as: [["workflow", EXTW]],
  },
  { id: "vertex", name: "GCP Vertex AI", does: "Google Cloud's platform for hosting models and running agents.", as: [["runtime", P60]] },
  { id: "bedrock", name: "Amazon Bedrock", does: "AWS platform for hosting models and running agents.", as: [["runtime", P60]] },
  { id: "nemoclaw", name: "NemoClaw", does: "Agent runtime. Hosts and orchestrates agents.", as: [["runtime", T61]] },
  {
    id: "em",
    name: "Event Management",
    host: "Enterprise-managed or on premises" + DECK,
    does: "Runs several collaborating agents on an enterprise-managed runtime. Its owner has not yet said what business job it does.",
    as: [
      ["runtime", "C C T N N N C | C T T T T T N N T T T C T C N N N | T*15 N | C C C C C N N | T N T T C C C C T | C T T C N"],
      ["multi", "C C C C N N C | C T T T T N N N N N N G T C N C C | T T T T C C T*9 C | C C N T C N N | G C N C C G C C P | C G G C C"],
    ],
  },
  {
    id: "entra",
    name: "ChatGPT Entra",
    does: "ChatGPT for employees, signed in through Entra ID.",
    as: [["conversational", "P G*6 | C C C G C C C N N C C C C3P C3P C N N | T*16 | T*7 | T*9 | T*5"]],
  },
  { id: "cglumi", name: "ChatGPT Lumi", does: "ChatGPT-based assistant known as Lumi.", as: [["conversational", P60]] },
  {
    id: "cgconn",
    name: "ChatGPT Connectors",
    does: "ChatGPT with connectors that let it read enterprise systems during a conversation.",
    as: [["conversational", "P T*6 | T*17 | C C N C C C C C C N N N N C C N | C3P C3P T C3P C3P C3P N | G T T T C C T T T | G T T T N"]],
  },
  {
    id: "cgagents",
    name: "ChatGPT Agents",
    does: "ChatGPT's agent mode. Carries out multi-step tasks for the person chatting.",
    as: [["conversational", P60]],
  },
  { id: "cowork", name: "Claude Cowork", does: "Anthropic's desktop agent for everyday knowledge work.", as: [["conversational", T61]] },
  {
    id: "adk",
    name: "Google ADK",
    does: "Google's Agent Development Kit, used to build systems of cooperating agents.",
    as: [["multi", T61]],
  },
  {
    id: "art",
    name: "Agent Red Teaming",
    host: "Enterprise-managed or on premises" + DECK,
    does: "Attacker, judge and orchestrator agents that work together to test other AI systems.",
    as: [["multi", "N*7 | C C C C T N N N C N C N N C N N N | T*15 N | N C N T N N N | C N N T C T N N T | T T T C C"]],
  },
  {
    id: "cgent",
    name: "ChatGPT Enterprise",
    does: "The connectors built into ChatGPT Enterprise that reach enterprise data.",
    as: [["native", T61]],
  },
  {
    id: "ccent",
    name: "Claude Code (Enterprise / Cowork)",
    does: "The connectors built into Claude's enterprise products.",
    as: [["native", T61]],
  },
  { id: "replit", name: "Replit Enterprise", does: "The connectors built into Replit Enterprise.", as: [["native", T61]] },
  {
    id: "lumi",
    name: "ChatGPT Enterprise – Lumi",
    does: "Custom connector that links ChatGPT Enterprise to Lumi.",
    as: [["custom", "P G*6 | " + CCI + CCR]],
  },
  {
    id: "tm1",
    name: "TM1",
    does: "Custom connector between ChatGPT Enterprise and TM1, the planning and analytics system.",
    as: [["custom", "G*7 | " + CCI + CCR]],
  },
  {
    id: "redteam",
    name: "Agent-Led Red Teaming Platform",
    does: "Backend service where agents attack and judge target AI models inside test environments.",
    as: [["backend", T61]],
  },
];
var AGENT = {},
  ASSESS = {};
AGENTS.forEach(function (a) {
  AGENT[a.id] = a;
  a.aids = [];
  a.as.forEach(function (p) {
    var aid = a.id + ":" + p[0];
    a.aids.push(aid);
    ASSESS[aid] = { agent: a.id, arch: p[0], base: X(p[1]) };
  });
});
var RAW = {
  "cursor:coding:OPS-01": "L1 - C",
  "codex:coding:OPS-01": "L0 - P",
  "devin:coding:OPS-01": "L0 - G",
  "devin:coding:DATA-04": "C3P(openAI) - G3P(anthropic)",
  "copilot:coding:DATA-04": "C3P(openAI) - G3P(anthropic)",
  "frontier:coding:OPS-08": "C3P,C",
  "frontier:workflow:OPS-08": "C3P,C",
  "legion:insights:DATA-05": "N?",
  "mspp:insights:DATA-06": "G?",
  "dining:workflow:ARCH-01": "NA",
  "travel:workflow:ARCH-01": "NA",
};
var RSTATUS = { draft: "Draft, not sent", waiting: "Waiting for a reply", answered: "Answered", closed: "Closed" };
var RPILL = { draft: "pill pending", waiting: "pill na", answered: "pill review", closed: "pill ok" };
var OUTCOMES = { changes: "Changes requested", conditions: "Accepted with conditions", complete: "Review complete" };
var BKEY = function (k) {
  return GAPS[k] ? "gap" : k === "TBD" ? "pending" : k === "N" ? "na" : "ok";
};
var STAGES = [
  ["Discover agents", "Reading the sample Zenity and ITAM feeds"],
  ["Match registration", "Matching records to registrations by stable ID"],
  ["Prepare scope", "Working out which assessments apply"],
  ["Prepare answers", "Checking observations against the evidence rules"],
  ["Draft questions", "Writing questions for what is still missing"],
  ["Prepare your review", "Lining up what needs your decision"],
];
var LAST = ["33 records", "29 matched", "36 assessments", "10 answers", "3 questions", "ready"];
var PREF = ["IAM-02", "DATA-02", "DATA-01", "OPS-05", "IAM-14", "NET-07", "IAM-05", "ASSET-04", "IAM-04", "DATA-03"];
function now() {
  var d = new Date(),
    h = d.getHours(),
    m = d.getMinutes();
  return (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m;
}
var SEED = [
  ["em:multi", "OPS-06", "C", "team"],
  ["em:multi", "DATA-04", "C"],
  ["em:runtime", "OPS-01", "P"],
  ["cursor:coding", "OPS-08", "C"],
  ["nucleus:insights", "IAM-02", "C"],
  ["decagon:workflow", "NET-04", "C3P"],
  ["entra:conversational", "IAM-04", "C"],
  ["copilot:coding", "OPS-04", "C"],
  ["prophet:insights", "OPS-05", "C"],
  ["frontier:coding", "IAM-05", "C"],
];

export {
  X,
  joinList,
  fmt,
  now,
  ST,
  GAPS,
  DISC,
  REQS,
  RIDX,
  ARCH,
  SHORT,
  AORDER,
  ALLICON,
  IAMC,
  NETA,
  NETB,
  NETF,
  DATC,
  DATD,
  ARC,
  T61,
  P60,
  FRI,
  CCI,
  CCR,
  EXTW,
  DECK,
  AGENTS,
  AGENT,
  ASSESS,
  RAW,
  RSTATUS,
  RPILL,
  OUTCOMES,
  BKEY,
  STAGES,
  LAST,
  PREF,
  SEED,
};
