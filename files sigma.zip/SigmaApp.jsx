import React from "react";
import {
  X,
  joinList,
  fmt,
  now,
  ST,
  GAPS,
  DISC,
  REQS,
  RIDX,
  ARCH,
  SHORT,
  AORDER,
  ALLICON,
  IAMC,
  NETA,
  NETB,
  NETF,
  DATC,
  DATD,
  ARC,
  T61,
  P60,
  FRI,
  CCI,
  CCR,
  EXTW,
  DECK,
  AGENTS,
  AGENT,
  ASSESS,
  RAW,
  RSTATUS,
  RPILL,
  OUTCOMES,
  BKEY,
  STAGES,
  LAST,
  PREF,
  SEED,
} from "./data.js";
import AgentScreen from "./screens/AgentScreen.jsx";
import AssistantPanel from "./screens/AssistantPanel.jsx";
import HomeScreen from "./screens/HomeScreen.jsx";
import ReportsScreen from "./screens/ReportsScreen.jsx";
import RequestsScreen from "./screens/RequestsScreen.jsx";
import "./sigma.css";

export default class SigmaApp extends React.Component {
  defaults() {
    if (this._d) {
      return this._d;
    }
    var props = SEED.map(function (x, i) {
      var team = x[3] === "team";
      return {
        id: "p" + i,
        aid: x[0],
        rid: x[1],
        from: ASSESS[x[0]].base[RIDX[x[1]]],
        to: x[2],
        state: "pending",
        reqId: team ? "r1" : "",
        source: team ? "From the Security Operations team's reply, 16 Sep" : "Prepared by SIGMA from a sample source observation, 16 Sep",
        reason: team
          ? "Sample reply: anomaly detection now covers the orchestrator and every participant agent in this workflow."
          : "Sample observation. It shows how a connected source proposes an answer together with its evidence.",
        evidence: team
          ? "Sample evidence: anomaly-detection test results for the multi-agent scope"
          : "Sample evidence: configuration export from the source system",
      };
    });
    this._d = {
      view: null,
      arch: "all",
      focus: "all",
      q: "",
      sort: "attention",
      agentId: "em",
      aIdx: 1,
      drawer: "",
      sel: "OPS-06",
      okOpen: false,
      naOpen: false,
      ans: {},
      purpose: {},
      owner: {},
      requests: [
        {
          id: "r1",
          aid: "em:multi",
          rid: "OPS-06",
          team: "Security Operations team",
          status: "answered",
          title: "Anomaly detection across the collaborating agents",
          messages: [
            {
              who: "You",
              at: "15 Sep",
              dir: "out",
              text: "For Event Management, assessed as a multi-agent workflow, the deck records Agent anomaly detection as a gap.\n\nWhich agents and delegation paths does anomaly detection cover today? Please share test evidence and name any remaining gap.",
            },
            {
              who: "Security Operations team",
              at: "16 Sep",
              dir: "in",
              text: "Sample reply: anomaly detection now covers the orchestrator and every participant agent in this workflow. Test results are attached.",
            },
          ],
        },
        {
          id: "r2",
          aid: "em:multi",
          rid: "IAM-12",
          team: "Identity and Access team",
          status: "draft",
          title: "Token activity monitoring between agents",
          messages: [
            {
              who: "You",
              at: "Draft",
              dir: "out",
              text: "For Event Management, assessed as a multi-agent workflow, Token activity monitoring is recorded as a gap, while the runtime assessment shows a control in place.\n\nDoes token monitoring cover tokens passed between the collaborating agents? Please share the monitoring scope and alert evidence.",
            },
          ],
        },
        {
          id: "r3",
          aid: "nucleus:insights",
          rid: "DATA-03",
          team: "Data Security team",
          status: "waiting",
          title: "Sensitive data loss prevention for Nucleus",
          messages: [
            {
              who: "You",
              at: "12 Sep",
              dir: "out",
              text: "For Nucleus, assessed as an insights agent, Sensitive data loss prevention is recorded as a gap.\n\nWhich DLP controls cover the prompts and outputs of this agent? Please share evidence, any remaining gap, its owner and a target date.",
            },
          ],
        },
      ],
      replyOpen: false,
      reply: { text: "", status: "C", evidence: "" },
      replyErr: "",
      proposals: props,
      recOpen: false,
      rec: { status: "C", note: "", evidence: "" },
      recErr: "",
      outcome: "",
      reviewer: "",
      note: "",
      rvErr: "",
      decisions: {},
      reports: [],
      reportTitle: "",
      chat: [
        {
          id: "m0",
          who: "sigma",
          text: "I am SIGMA, the agent behind this workspace. I discover agents, match them to their registrations, prepare evidence-backed answers and draft questions for the right teams.\n\nTell me to run, to show one archetype, to find the worst gaps or to draft a question. Whatever I prepare waits for your decision.",
        },
      ],
      draft: "",
      thinking: false,
      asstOpen: null,
      toast: "",
      seq: 100,
      tab: "chat",
      run: { status: "idle", stage: -1, scope: "all", res: {}, nums: {}, summary: "" },
      log: [
        { head: true, at: "16 Sep", stage: "Run across the workspace", text: "" },
        { at: "09:12", stage: "Discover agents", text: "Read 33 agent records from the sample Zenity and ITAM feeds." },
        { at: "09:12", stage: "Match registration", text: "29 matched by stable ID. 4 still need an owner to claim them." },
        { at: "09:12", stage: "Prepare scope", text: "36 assessments across 9 archetypes, 61 requirements each." },
        { at: "09:13", stage: "Prepare answers", text: "10 observations passed the evidence check and went to In review." },
        { at: "09:13", stage: "Draft questions", text: "3 questions drafted. Requirements with an open conversation were skipped." },
        { at: "09:13", stage: "Prepare your review", text: "Done. 10 answers are waiting for a decision." },
      ],
    };
    return this._d;
  }
  S() {
    return Object.assign({}, this.defaults(), this.state || {});
  }
  componentWillUnmount() {
    clearTimeout(this._tt);
    clearTimeout(this._rt);
  }
  view(s) {
    var v = s.view || this.props.startScreen || "agents";
    return v === "agents" ? "home" : v;
  }
  code(s, aid, rid) {
    var o = s.ans[aid + ":" + rid];
    return o ? o.status : ASSESS[aid].base[RIDX[rid]] || "TBD";
  }
  reqName(aid, rid) {
    return rid === "OPS-01" ? "Kill switch, " + ARCH[ASSESS[aid].arch].ks : REQS[RIDX[rid]].name;
  }
  pmap(s) {
    var m = {};
    s.proposals.forEach(function (p) {
      if (p.state === "pending") {
        m[p.aid + ":" + p.rid] = p;
      }
    });
    return m;
  }
  bucket(s, pm, aid, rid) {
    return pm[aid + ":" + rid] ? "review" : BKEY(this.code(s, aid, rid));
  }
  counts(s, pm, aids) {
    var c = { gap: 0, pending: 0, review: 0, ok: 0, na: 0 };
    aids.forEach((aid) => {
      REQS.forEach((r) => {
        c[this.bucket(s, pm, aid, r.id)]++;
      });
    });
    return c;
  }
  reqFor(s, aid, rid) {
    var l = s.requests.filter(function (x) {
      return x.aid === aid && x.rid === rid;
    });
    return (
      l.filter(function (x) {
        return x.status !== "closed";
      })[0] || l[l.length - 1]
    );
  }
  say(patch, msg) {
    this.setState(Object.assign({}, patch, { toast: msg }));
    clearTimeout(this._tt);
    this._tt = setTimeout(() => this.setState({ toast: "" }), 5200);
  }
  openAgent(id, aIdx) {
    this.setState({ view: "agent", agentId: id, aIdx: aIdx || 0, drawer: "", okOpen: false, naOpen: false, recOpen: false });
  }
  openReq(aid, rid) {
    var a = AGENT[ASSESS[aid].agent];
    this.setState({
      view: "agent",
      agentId: a.id,
      aIdx: a.aids.indexOf(aid),
      drawer: "req",
      sel: rid,
      recOpen: false,
      recErr: "",
      replyOpen: false,
      replyErr: "",
    });
  }
  draftFor(s, aid, rid) {
    var r = REQS[RIDX[rid]],
      A = ASSESS[aid],
      k = this.code(s, aid, rid),
      nm = this.reqName(aid, rid);
    return {
      team: DISC[r.di].team,
      title: nm + " for " + AGENT[A.agent].name,
      body:
        "For " +
        AGENT[A.agent].name +
        ", assessed under " +
        ARCH[A.arch].name.toLowerCase() +
        ', "' +
        nm +
        '" is currently recorded as ' +
        ST[k].label.toLowerCase() +
        ".\n\nWe need: " +
        r.guide.charAt(0).toLowerCase() +
        r.guide.slice(1) +
        "\n\nPlease tell us what is in place for this scope, share evidence we can link, and name any remaining gap with its owner and a target date.",
    };
  }
  askTeam(aid, rid) {
    var s = this.S(),
      ex = this.reqFor(s, aid, rid);
    if (ex && ex.status !== "closed") {
      this.openReq(aid, rid);
      return;
    }
    var dft = this.draftFor(s, aid, rid),
      a = AGENT[ASSESS[aid].agent];
    var nr = {
      id: "r" + s.seq,
      aid: aid,
      rid: rid,
      team: dft.team,
      status: "draft",
      title: dft.title,
      messages: [{ who: "You", at: "Draft", dir: "out", text: dft.body }],
    };
    this.say(
      {
        requests: s.requests.concat([nr]),
        seq: s.seq + 1,
        view: "agent",
        agentId: a.id,
        aIdx: a.aids.indexOf(aid),
        drawer: "req",
        sel: rid,
        recOpen: false,
      },
      "Question drafted for the " + dft.team + ". Read it, then send it.",
    );
  }
  patchReq(s, id, fn) {
    return s.requests.map(function (r) {
      return r.id === id ? fn(Object.assign({}, r)) : r;
    });
  }
  queue(id) {
    var s = this.S();
    this.say(
      {
        requests: this.patchReq(s, id, function (r) {
          r.status = "waiting";
          r.messages = r.messages.map(function (m) {
            return Object.assign({}, m, { at: "17 Sep" });
          });
          return r;
        }),
      },
      "Question sent. It stays under Pending, marked as waiting for a reply.",
    );
  }
  toggleReply(id) {
    var s = this.S();
    this.setState({
      replyOpen: !s.replyOpen,
      replyErr: "",
      reply:
        id === "r3"
          ? {
              text: "Sample reply: DLP policies inspect the prompts and outputs of this agent. Policy export attached.",
              status: "C",
              evidence: "Sample evidence: DLP policy export for the Nucleus scope",
            }
          : { text: "", status: "C", evidence: "" },
    });
  }
  saveReply(id) {
    var s = this.S(),
      rp = s.reply;
    if (!rp.text.trim() || !rp.evidence.trim()) {
      this.setState({ replyErr: "Add what the team said and the evidence they gave. A status without evidence cannot go to review." });
      return;
    }
    var req = s.requests.filter(function (x) {
      return x.id === id;
    })[0];
    var np = {
      id: "p" + s.seq,
      aid: req.aid,
      rid: req.rid,
      from: this.code(s, req.aid, req.rid),
      to: rp.status,
      state: "pending",
      reqId: id,
      source: "From the " + req.team + "'s reply, 17 Sep",
      reason: rp.text.trim(),
      evidence: rp.evidence.trim(),
    };
    var keep = s.proposals.map(function (p) {
      return p.state === "pending" && p.aid === req.aid && p.rid === req.rid ? Object.assign({}, p, { state: "superseded" }) : p;
    });
    this.say(
      {
        requests: this.patchReq(s, id, function (r) {
          r.status = "answered";
          r.messages = r.messages.concat([
            { who: r.team, at: "17 Sep", dir: "in", text: rp.text.trim() + "\n\nEvidence: " + rp.evidence.trim() },
          ]);
          return r;
        }),
        proposals: keep.concat([np]),
        replyOpen: false,
        replyErr: "",
        seq: s.seq + 1,
      },
      "Reply saved. The new answer moved to In review.",
    );
  }
  decide(pid, accept) {
    var s = this.S(),
      p = s.proposals.filter(function (x) {
        return x.id === pid;
      })[0];
    if (!p) {
      return;
    }
    var patch = {
      proposals: s.proposals.map(function (x) {
        return x.id === pid ? Object.assign({}, x, { state: accept ? "accepted" : "dismissed" }) : x;
      }),
    };
    var nm = this.reqName(p.aid, p.rid),
      multi = AGENT[ASSESS[p.aid].agent].aids.length > 1;
    if (accept) {
      var ans = Object.assign({}, s.ans);
      ans[p.aid + ":" + p.rid] = { status: p.to, origin: p.reqId ? "team" : "source", evidence: [{ label: p.source, detail: p.evidence }] };
      patch.ans = ans;
      this.say(
        patch,
        "Accepted. " +
          nm +
          ' is now "' +
          ST[p.to].label +
          '"' +
          (multi ? " under " + ARCH[ASSESS[p.aid].arch].name.toLowerCase() + ". The other assessment is unchanged." : "."),
      );
    } else {
      this.say(patch, "Dismissed. " + nm + " keeps its current answer and the proposal stays on record.");
    }
  }
  closeReq(id) {
    var s = this.S();
    this.say(
      {
        requests: this.patchReq(s, id, function (r) {
          r.status = "closed";
          return r;
        }),
      },
      "Conversation closed.",
    );
  }
  saveRec(aid, rid) {
    var s = this.S(),
      rc = s.rec;
    if (!rc.evidence.trim() || !rc.note.trim()) {
      this.setState({ recErr: "Add the evidence and a short reason. A status alone is not a complete answer." });
      return;
    }
    var ans = Object.assign({}, s.ans);
    ans[aid + ":" + rid] = {
      status: rc.status,
      origin: "manual",
      evidence: [{ label: "Recorded here, 17 Sep 2026", detail: rc.evidence.trim() + " " + rc.note.trim() }],
    };
    this.say(
      { ans: ans, recOpen: false, recErr: "", rec: { status: "C", note: "", evidence: "" } },
      'Answer saved as "' + ST[rc.status].label + '" with your evidence.',
    );
  }
  startRun(scope) {
    var s = this.S();
    if (s.run.status === "running") {
      return;
    }
    this.setState({
      run: { status: "running", stage: 0, scope: scope, res: {}, nums: {}, summary: "" },
      log: s.log.concat([
        { head: true, at: "17 Sep", stage: scope === "all" ? "Run across the workspace" : "Run on " + AGENT[scope].name, text: "" },
      ]),
      tab: "act",
      asstOpen: true,
    });
    this.tick();
  }
  tick() {
    clearTimeout(this._rt);
    this._rt = setTimeout(() => {
      var s = this.S(),
        r = s.run;
      if (r.status !== "running") {
        return;
      }
      var out = this.doStage(s, r),
        res = Object.assign({}, r.res),
        nums = Object.assign({}, r.nums, out.nums || {}),
        last = r.stage === 5;
      res[r.stage] = out.sub;
      var patch = Object.assign({}, out.patch || {}, {
        run: {
          status: last ? "done" : "running",
          stage: last ? 6 : r.stage + 1,
          scope: r.scope,
          res: res,
          nums: nums,
          summary: last ? out.text : "",
        },
        log: s.log.concat([{ at: now(), stage: STAGES[r.stage][0], text: out.text }]),
      });
      if (last) {
        patch.chat = s.chat.concat([
          {
            id: "m" + Date.now(),
            who: "sigma",
            text:
              "Run finished" +
              (r.scope === "all" ? "" : " on " + AGENT[r.scope].name) +
              ". " +
              out.text +
              "\n\nNothing changed yet. Each answer waits for you under In review.",
            items: (nums.list || []).slice(0, 4),
            actions: nums.drafts ? [{ label: "See drafted questions", kind: "requests" }] : [],
          },
        ]);
        this.say(patch, "SIGMA finished. " + (nums.props || 0) + " new answers are in review.");
      } else {
        this.setState(patch);
        this.tick();
      }
    }, 1050);
  }
  doStage(s, r) {
    var self = this,
      pm = this.pmap(s),
      list = r.scope === "all" ? AGENTS : [AGENT[r.scope]],
      nA = 0,
      archs = {};
    list.forEach(function (a) {
      a.as.forEach(function (p) {
        nA++;
        archs[p[0]] = 1;
      });
    });
    if (r.stage === 0) {
      return {
        sub: list.length + (list.length === 1 ? " record" : " records"),
        text: "Read " + list.length + (list.length === 1 ? " agent record" : " agent records") + " from the sample Zenity and ITAM feeds.",
      };
    }
    if (r.stage === 1) {
      var un = r.scope === "all" ? 4 : 0;
      return {
        sub: list.length - un + " matched",
        text:
          list.length -
          un +
          " matched by stable ID." +
          (un ? " " + un + " still need an owner to claim them." : " Name similarity alone is never used to merge records."),
      };
    }
    if (r.stage === 2) {
      var nk = Object.keys(archs).length;
      return {
        sub: nA + (nA === 1 ? " assessment" : " assessments"),
        text:
          nA +
          (nA === 1 ? " assessment" : " assessments") +
          " across " +
          nk +
          (nk === 1 ? " archetype" : " archetypes") +
          ", 61 requirements each.",
      };
    }
    if (r.stage === 3) {
      var picks = [],
        max = r.scope === "all" ? 5 : 3;
      var agents =
        r.scope === "all"
          ? AGENTS.filter(function (a) {
              return !a.aids.some(function (aid) {
                return REQS.some(function (q) {
                  return pm[aid + ":" + q.id];
                });
              });
            })
          : list;
      agents.forEach(function (a) {
        a.aids.forEach(function (aid) {
          var got = 0;
          PREF.forEach(function (rid) {
            if (
              picks.length < max &&
              got < (r.scope === "all" ? 1 : 2) &&
              self.bucket(s, pm, aid, rid) === "pending" &&
              !self.reqFor(s, aid, rid)
            ) {
              picks.push({ aid: aid, rid: rid, to: picks.length % 3 === 1 ? "C3P" : "C" });
              got++;
            }
          });
        });
      });
      if (!picks.length && r.scope !== "all") {
        list[0].aids.forEach(function (aid) {
          REQS.forEach(function (q) {
            if (
              picks.length < 2 &&
              self.bucket(s, pm, aid, q.id) === "gap" &&
              self.code(s, aid, q.id) === "G" &&
              !self.reqFor(s, aid, q.id)
            ) {
              picks.push({ aid: aid, rid: q.id, to: "P" });
            }
          });
        });
      }
      var seq = s.seq,
        props = picks.map(function (p) {
          return {
            id: "p" + seq++,
            aid: p.aid,
            rid: p.rid,
            from: self.code(s, p.aid, p.rid),
            to: p.to,
            state: "pending",
            reqId: "",
            source: "Prepared by SIGMA from a sample source observation, 17 Sep",
            reason:
              p.to === "P"
                ? "Sample observation. Part of this scope now shows a control, so the gap would become partial."
                : "Sample observation. It shows how SIGMA proposes an answer together with its evidence.",
            evidence: "Sample evidence: configuration export from the source system",
          };
        });
      return {
        patch: { proposals: s.proposals.concat(props), seq: seq },
        nums: {
          props: props.length,
          list: props.map(function (p) {
            return {
              label: self.reqName(p.aid, p.rid) + ": " + ST[p.from].label.toLowerCase() + " becomes " + ST[p.to].label.toLowerCase(),
              sub: AGENT[ASSESS[p.aid].agent].name + ", " + ARCH[ASSESS[p.aid].arch].name,
              bucket: "review",
              act: { kind: "req", aid: p.aid, rid: p.rid },
            };
          }),
        },
        sub: props.length + (props.length === 1 ? " answer" : " answers"),
        text: props.length
          ? props.length + (props.length === 1 ? " observation" : " observations") + " passed the evidence check and went to In review."
          : "No new observation passed the evidence check this time.",
      };
    }
    if (r.stage === 4) {
      var maxD = r.scope === "all" ? 2 : 1,
        drafts = [],
        seq2 = s.seq;
      list
        .map(function (a) {
          return { a: a, g: self.counts(s, pm, a.aids).gap };
        })
        .sort(function (x, y) {
          return y.g - x.g;
        })
        .forEach(function (x) {
          if (drafts.length >= maxD) {
            return;
          }
          var found = null;
          x.a.aids.forEach(function (aid) {
            REQS.forEach(function (q) {
              if (!found && self.bucket(s, pm, aid, q.id) === "gap" && q.di >= 1 && !self.reqFor(s, aid, q.id)) {
                found = { aid: aid, rid: q.id };
              }
            });
          });
          if (found) {
            var dft = self.draftFor(s, found.aid, found.rid);
            drafts.push({
              id: "r" + seq2++,
              aid: found.aid,
              rid: found.rid,
              team: dft.team,
              status: "draft",
              title: dft.title,
              messages: [{ who: "SIGMA, for you to send", at: "Draft", dir: "out", text: dft.body }],
            });
          }
        });
      return {
        patch: { requests: s.requests.concat(drafts), seq: seq2 },
        nums: { drafts: drafts.length },
        sub: drafts.length + (drafts.length === 1 ? " question" : " questions"),
        text:
          drafts.length +
          (drafts.length === 1 ? " question" : " questions") +
          " drafted. Requirements with an open conversation were skipped.",
      };
    }
    return {
      sub: "ready",
      text:
        (r.nums.props || 0) +
        ((r.nums.props || 0) === 1 ? " answer is" : " answers are") +
        " waiting in In review and " +
        (r.nums.drafts || 0) +
        ((r.nums.drafts || 0) === 1 ? " drafted question is" : " drafted questions are") +
        " ready to send.",
    };
  }
  findReq(t) {
    var stop = {
      security: 1,
      enforcement: 1,
      perimeter: 1,
      network: 1,
      agent: 1,
      management: 1,
      control: 1,
      data: 1,
      public: 1,
      cloud: 1,
      code: 1,
      with: 1,
    };
    var best = null,
      bs = 0;
    REQS.forEach(function (r) {
      if (t.indexOf(r.id.toLowerCase()) >= 0) {
        best = r;
        bs = 99;
        return;
      }
      var sc = 0;
      r.name
        .toLowerCase()
        .split(/[^a-z]+/)
        .forEach(function (w) {
          if (w.length > 3 && !stop[w] && t.indexOf(w) >= 0) {
            sc += w.length > 6 ? 2 : 1;
          }
        });
      if (sc > bs) {
        bs = sc;
        best = r;
      }
    });
    return bs >= 2 ? best : null;
  }
  topAgents(s, pm, list, key) {
    return list
      .map((a) => ({ a: a, c: this.counts(s, pm, a.aids) }))
      .sort(function (x, y) {
        return y.c[key] - x.c[key];
      })
      .slice(0, 5)
      .map(function (x) {
        return {
          label: x.a.name + ": " + x.c[key] + (key === "gap" ? " gaps" : key === "pending" ? " pending" : " in review"),
          sub: joinList(
            x.a.as.map(function (p) {
              return ARCH[p[0]].name;
            }),
          ),
          bucket: key,
          act: { kind: "agent", id: x.a.id },
        };
      });
  }
  reply(q) {
    var s = this.S(),
      t = q.toLowerCase(),
      view = this.view(s),
      inAgent = view === "agent",
      pm = this.pmap(s);
    var ag = AGENT[s.agentId],
      aid = ag.aids[Math.min(s.aIdx, ag.aids.length - 1)],
      A = ASSESS[aid],
      an = ARCH[A.arch].name,
      m = { id: "m" + Date.now(), who: "sigma", text: "" };
    var asks = /mean|stand for|what is a|what is an|what does|what's a|explain/.test(t),
      portfolio = !inAgent || /agents|workspace|portfolio|everything|overall/.test(t);
    if (asks && /archetype/.test(t)) {
      m.text =
        "An archetype describes how an agent operates: a coding agent, a conversational agent, a platform other agents run on, and so on. It decides which questions make sense.\n\nAn agent can have more than one archetype. Each one gets its own assessment of all 61 requirements, so an answer in one never leaks into another.";
      m.basis = "the nine archetypes in the programme deck";
      return m;
    }
    if (asks && /rcsa/.test(t)) {
      m.text =
        "RCSA is the risk and control self-assessment record, the programme's documentation of a control.\n\nSIGMA tracks three things separately for every control: whether it is technically implemented, whether its RCSA documentation is done, and whether it has an operating metric.";
      return m;
    }
    if (asks && /(pending|in review|gap)\b/.test(t) && !/g3p|tbd/.test(t)) {
      m.text =
        "Every requirement sits in exactly one place.\n\nGaps: a control is missing or only partial.\nPending: nobody has answered yet. That is not the same as a gap.\nIn review: a new answer arrived from a team, an upload or a connected source, and it waits for your decision.\nIn place and Not applicable are folded away below the board.";
      return m;
    }
    if (asks) {
      var codes = ["G3PG", "G3P", "C3P", "TBD", "GE", "C", "G", "N", "P"];
      for (var i = 0; i < codes.length; i++) {
        if (new RegExp("(^|[^a-z0-9])" + codes[i].toLowerCase() + "([^a-z0-9]|$)").test(t)) {
          var k = codes[i];
          m.text =
            k +
            " is the deck's code for \"" +
            ST[k].label +
            '". ' +
            ST[k].long +
            "\n\nIn SIGMA it shows up under " +
            { gap: "Gaps", pending: "Pending", ok: "In place", na: "Not applicable" }[BKEY(k)] +
            ".";
          m.basis = "the status vocabulary in the programme deck";
          return m;
        }
      }
    }
    if (/\b(run|scan|rescan|refresh|rerun)\b/.test(t)) {
      if (s.run.status === "running") {
        m.text = "I am already running. Watch the Activity tab. I will tell you when I am done.";
        return m;
      }
      var sc = inAgent && !/workspace|all|everything|every/.test(t) ? ag.id : "all";
      this.startRun(sc);
      m.text =
        "Starting a run " +
        (sc === "all" ? "across the workspace" : "on " + ag.name) +
        ". I discover, match, prepare answers and draft questions, in that order. Follow it under Activity.\n\nNothing I find changes an answer until you accept it.";
      return m;
    }
    if (/add (an |a )?(new )?agent|new agent|register/.test(t)) {
      m.text =
        "To add an agent I need three things: its name, what it does and for whom, and the team that owns it.\n\nI search existing records first so we do not create a duplicate. A matching name alone is never treated as the same agent.\n\nNew-agent intake is planned next. The upload flow shows how it will work.";
      m.link = true;
      return m;
    }
    var hit = null;
    if (/show|filter|list|only|which|see|open/.test(t)) {
      ["multi"].concat(AORDER).forEach(function (kk) {
        if (!hit && ARCH[kk].key.test(t)) {
          hit = kk;
        }
      });
    }
    if (hit) {
      var lst = AGENTS.filter(function (a) {
          return a.as.some(function (p) {
            return p[0] === hit;
          });
        }),
        aids = lst.map(function (a) {
          return a.id + ":" + hit;
        }),
        c = this.counts(s, pm, aids);
      this.setState({ view: "home", arch: hit, focus: "all", q: "", drawer: "" });
      m.text =
        "Showing " +
        ARCH[hit].name.toLowerCase() +
        ": " +
        lst.length +
        (lst.length === 1 ? " agent" : " agents") +
        ".\n\n" +
        ARCH[hit].does +
        "\n\nTogether they have " +
        c.gap +
        " gaps, " +
        c.pending +
        " pending and " +
        c.review +
        " in review.";
      m.items = this.topAgents(s, pm, lst, "gap").slice(0, 3);
      return m;
    }
    if (/draft|ask |question|request/.test(t) && !/what should/.test(t)) {
      var r = this.findReq(t) || REQS[RIDX[s.sel]],
        ex = this.reqFor(s, aid, r.id);
      if (ex && ex.status !== "closed") {
        m.text =
          "There is already a conversation about " +
          this.reqName(aid, r.id) +
          " for " +
          ag.name +
          " (" +
          RSTATUS[ex.status].toLowerCase() +
          "). I will not start a second one.";
        m.actions = [{ label: "Open it", kind: "req", aid: aid, rid: r.id, pri: true }];
        return m;
      }
      var dft = this.draftFor(s, aid, r.id);
      m.text = "Here is a draft for the " + dft.team + ". I have not created anything yet.\n\n" + dft.body;
      m.actions = [
        { label: "Create this draft", kind: "ask", aid: aid, rid: r.id, pri: true },
        { label: "Open the requirement", kind: "req", aid: aid, rid: r.id },
      ];
      m.basis = ag.name + ", " + an + ", " + r.id;
      return m;
    }
    if (/summar|leadership|overview|how are we doing/.test(t)) {
      var list = portfolio ? Object.keys(ASSESS) : ag.aids,
        ct = this.counts(s, pm, list),
        rev = Object.keys(s.ans).length;
      m.text =
        (portfolio
          ? "This workspace holds " + AGENTS.length + " agents and " + list.length + " assessments"
          : ag.name + " has " + list.length + (list.length > 1 ? " assessments" : " assessment")) +
        ", " +
        fmt(list.length * 61) +
        " requirement answers in all.\n\n" +
        fmt(ct.gap) +
        " are gaps, " +
        fmt(ct.pending) +
        " are pending and " +
        ct.review +
        " are in review. " +
        fmt(ct.ok) +
        " are stated as in place.\n\n" +
        rev +
        (rev === 1 ? " answer has" : " answers have") +
        " been reviewed in this workspace so far. The rest come from the deck, so treat them as history rather than verification.";
      m.actions = inAgent && !portfolio ? [{ label: "Record a review outcome", kind: "review", pri: true }] : [];
      m.basis = fmt(list.length * 61) + " answers, counted live";
      return m;
    }
    if (/review|proposal|approve|waiting for me|decision/.test(t)) {
      var ps = s.proposals.filter(function (p) {
        return p.state === "pending" && (portfolio || AGENT[ASSESS[p.aid].agent] === ag);
      });
      m.text = ps.length
        ? ps.length +
          (ps.length === 1 ? " new answer is" : " new answers are") +
          " waiting for a decision" +
          (portfolio ? " across the workspace." : " on " + ag.name + ".")
        : "Nothing is waiting for review" + (portfolio ? "." : " on " + ag.name + ".");
      m.items = ps
        .slice(0, 6)
        .map((p) => ({
          label: this.reqName(p.aid, p.rid) + ": " + ST[p.from].label.toLowerCase() + " becomes " + ST[p.to].label.toLowerCase(),
          sub: AGENT[ASSESS[p.aid].agent].name + ", " + ARCH[ASSESS[p.aid].arch].name,
          bucket: "review",
          act: { kind: "req", aid: p.aid, rid: p.rid },
        }));
      return m;
    }
    if (/next|what should|where do i start|to do|todo/.test(t)) {
      var items = [];
      s.proposals
        .filter(function (p) {
          return p.state === "pending" && (!inAgent || AGENT[ASSESS[p.aid].agent] === ag);
        })
        .slice(0, 3)
        .forEach((p) =>
          items.push({
            label: "Decide on " + this.reqName(p.aid, p.rid),
            sub: AGENT[ASSESS[p.aid].agent].name + ", in review",
            bucket: "review",
            act: { kind: "req", aid: p.aid, rid: p.rid },
          }),
        );
      s.requests
        .filter(function (x) {
          return x.status === "draft";
        })
        .forEach((x) =>
          items.push({
            label: "Send your draft: " + x.title,
            sub: "To the " + x.team,
            bucket: "pending",
            act: { kind: "req", aid: x.aid, rid: x.rid },
          }),
        );
      s.requests
        .filter(function (x) {
          return x.status === "waiting";
        })
        .forEach((x) =>
          items.push({
            label: "Record the reply when it arrives: " + x.title,
            sub: "Waiting on the " + x.team,
            act: { kind: "req", aid: x.aid, rid: x.rid },
          }),
        );
      if (inAgent) {
        var g = REQS.filter((r2) => this.bucket(s, pm, aid, r2.id) === "gap" && !this.reqFor(s, aid, r2.id))[0];
        if (g) {
          items.push({
            label: "Ask about the gap in " + this.reqName(aid, g.id),
            sub: ag.name + ", " + an,
            bucket: "gap",
            act: { kind: "req", aid: aid, rid: g.id },
          });
        }
      }
      m.text = "Most useful first. Each one opens the exact place to act.";
      m.items = items.slice(0, 5);
      return m;
    }
    if (/kill|compare|differ|why (two|three|separate|2|3)|two assessments/.test(t)) {
      var c2 = inAgent ? ag : AGENT.em;
      if (c2.aids.length < 2) {
        m.text =
          c2.name +
          " has one archetype, so there is nothing to compare. Event Management and OpenAI Frontier are each assessed more than once.";
        m.actions = [{ label: "Open Event Management", kind: "agent", id: "em" }];
        return m;
      }
      var diffs = /kill/.test(t)
        ? [REQS[RIDX["OPS-01"]]]
        : REQS.filter((r3) => {
            var f = this.code(s, c2.aids[0], r3.id);
            return c2.aids.some((a) => this.code(s, a, r3.id) !== f) && c2.aids.every((a) => this.code(s, a, r3.id) !== "N");
          });
      m.text =
        c2.name +
        " works in " +
        c2.aids.length +
        " ways, so it is assessed " +
        c2.aids.length +
        " times. The same requirement can have a different answer in each, which is why they are kept apart.";
      m.items = diffs
        .slice(0, 4)
        .map((r4) => ({
          label: r4.name,
          sub:
            c2.aids
              .map(
                (a) =>
                  ARCH[ASSESS[a].arch].name +
                  (r4.id === "OPS-01" ? " (" + ARCH[ASSESS[a].arch].ks + ")" : "") +
                  ": " +
                  ST[this.code(s, a, r4.id)].label.toLowerCase(),
              )
              .join(". ") + ".",
          act: { kind: "req", aid: c2.aids[c2.aids.length - 1], rid: r4.id },
        }));
      return m;
    }
    var key = /pending|unknown|tbd|missing|unanswered/.test(t) ? "pending" : /gap|risk|problem|worst/.test(t) ? "gap" : "";
    if (key && portfolio) {
      m.text =
        key === "gap"
          ? "The agents with the most gaps, counted across each of their assessments."
          : "The agents with the most unanswered requirements. Pending means nobody has answered yet, not that a control is missing.";
      m.items = this.topAgents(s, pm, AGENTS, key);
      return m;
    }
    if (key) {
      var rs = REQS.filter((r6) => this.bucket(s, pm, aid, r6.id) === key);
      m.text =
        ag.name +
        ", " +
        an.toLowerCase() +
        ": " +
        rs.length +
        (key === "gap" ? " gaps." : " pending. Nobody has answered these yet, which is not the same as a gap.") +
        (rs.length > 6 ? " The first six:" : "");
      m.items = rs
        .slice(0, 6)
        .map((r7) => ({
          label: this.reqName(aid, r7.id),
          sub: DISC[r7.di].name + ", " + ST[this.code(s, aid, r7.id)].label.toLowerCase(),
          bucket: key,
          act: { kind: "req", aid: aid, rid: r7.id },
        }));
      return m;
    }
    if (/upload|import|file|evidence|document/.test(t)) {
      m.text =
        "You will be able to upload four kinds of material: an agent inventory, an existing assessment, evidence, and design documents.\n\nSIGMA shows what it read and where in the file it found it before anything changes. Each row lands under In review. An upload never overwrites a reviewed answer.";
      m.link = true;
      return m;
    }
    m.text = "I answer from what is recorded in this workspace, so I may not have that. These are things I can do right now.";
    m.actions = [
      { label: "Which agents have the most gaps?", kind: "prompt" },
      { label: "Show only coding agents", kind: "prompt" },
      { label: "What is waiting for review?", kind: "prompt" },
    ];
    return m;
  }
  act(a) {
    if (!a) {
      return;
    }
    if (a.kind === "req") {
      this.openReq(a.aid, a.rid);
    } else if (a.kind === "ask") {
      this.askTeam(a.aid, a.rid);
    } else if (a.kind === "agent") {
      this.openAgent(a.id);
    } else if (a.kind === "review") {
      this.setState({ view: "agent", drawer: "review" });
    } else if (a.kind === "requests") {
      this.setState({ view: "requests", drawer: "" });
    } else if (a.kind === "prompt") {
      this.send(a.label);
    }
  }
  send(text) {
    var s = this.S(),
      v = (text == null ? s.draft : text).trim();
    if (!v) {
      return;
    }
    this.setState({
      chat: s.chat.concat([{ id: "u" + Date.now(), who: "user", text: v }]),
      draft: "",
      thinking: true,
      asstOpen: true,
      tab: "chat",
    });
    setTimeout(() => {
      var r = this.reply(v),
        s2 = this.S();
      this.setState({ chat: s2.chat.concat([r]), thinking: false });
    }, 560);
  }

  renderVals() {
    var s = this.S(),
      view = this.view(s),
      self = this,
      pm = this.pmap(s);
    var asstOpen = s.asstOpen == null ? (this.props.assistantOpen == null ? true : !!this.props.assistantOpen) : s.asstOpen;
    var set = function (k) {
      return function (e) {
        var p = {};
        p[k] = e.target.value;
        self.setState(p);
      };
    };
    var ag = AGENT[s.agentId] || AGENTS[0],
      aIdx = Math.min(s.aIdx, ag.aids.length - 1),
      aid = ag.aids[aIdx],
      A = ASSESS[aid],
      M = ARCH[A.arch];
    var pillOf = function (k) {
      return "pill " + BKEY(k);
    };

    // home
    var inArch = function (a, key) {
      return (
        key === "all" ||
        a.as.some(function (p) {
          return p[0] === key;
        })
      );
    };
    var scoped = function (a) {
      return s.arch === "all" ? a.aids : [a.id + ":" + s.arch];
    };
    var rail = [{ key: "all", name: "All agents", icon: ALLICON }]
      .concat(
        AORDER.map(function (k) {
          return { key: k, name: ARCH[k].name, icon: ARCH[k].icon };
        }),
      )
      .map(function (r) {
        var lst = AGENTS.filter(function (a) {
            return inArch(a, r.key);
          }),
          aids = [];
        lst.forEach(function (a) {
          (r.key === "all" ? a.aids : [a.id + ":" + r.key]).forEach(function (x) {
            aids.push(x);
          });
        });
        return {
          name: r.name,
          icon: r.icon,
          count: lst.length,
          on: view === "home" && s.arch === r.key,
          cls: view === "home" && s.arch === r.key ? "rail on" : "rail",
          b: self.counts(s, pm, aids),
          pick: function () {
            self.setState({ arch: r.key, view: "home", drawer: "" });
          },
        };
      });
    var ql = s.q.trim().toLowerCase();
    var rows = AGENTS.filter(function (a) {
      return inArch(a, s.arch) && (!ql || (a.name + " " + a.does).toLowerCase().indexOf(ql) >= 0);
    })
      .map(function (a) {
        return { a: a, b: self.counts(s, pm, scoped(a)) };
      })
      .filter(function (x) {
        return s.focus === "all" || x.b[s.focus] > 0;
      });
    rows.sort(
      s.sort === "name"
        ? function (x, y) {
            return x.a.name.localeCompare(y.a.name);
          }
        : function (x, y) {
            return y.b.review - x.b.review || y.b.gap - x.b.gap || y.b.pending - x.b.pending;
          },
    );
    var tot = { gap: 0, pending: 0, review: 0, ok: 0, na: 0 },
      nAssess = 0;
    rows.forEach(function (x) {
      nAssess += scoped(x.a).length;
      ["gap", "pending", "review", "ok", "na"].forEach(function (k) {
        tot[k] += x.b[k];
      });
    });
    var tcls = function (k) {
        return "tile " + k + (s.focus === k ? " on" : "");
      },
      tpick = function (k) {
        return function () {
          self.setState({ focus: s.focus === k ? "all" : k });
        };
      };
    var home = {
      title: s.arch === "all" ? "All agents" : ARCH[s.arch].name,
      sub:
        s.arch === "all"
          ? "Every AI agent under security review. Pick an archetype on the left to see one kind of agent."
          : ARCH[s.arch].does,
      gap: fmt(tot.gap),
      pending: fmt(tot.pending),
      review: fmt(tot.review),
      ok: fmt(tot.ok),
      b: tot,
      tGap: tcls("gap"),
      tPending: tcls("pending"),
      tReview: tcls("review"),
      tOk: tcls("ok"),
      onGap: s.focus === "gap",
      onPending: s.focus === "pending",
      onReview: s.focus === "review",
      onOk: s.focus === "ok",
      pGap: tpick("gap"),
      pPending: tpick("pending"),
      pReview: tpick("review"),
      pOk: tpick("ok"),
      unit:
        (s.focus === "all"
          ? "Across "
          : "Only agents with " +
            { gap: "gaps", pending: "pending answers", review: "answers in review", ok: "controls in place" }[s.focus] +
            ": ") +
        rows.length +
        (rows.length === 1 ? " agent" : " agents") +
        " and " +
        fmt(nAssess * 61) +
        " requirement answers",
    };
    var agents = rows.map(function (x) {
      return {
        name: x.a.name,
        does: s.purpose[x.a.id] || x.a.does,
        ext: !!x.a.ext,
        b: x.b,
        chips: x.a.as.map(function (p) {
          return { name: SHORT[p[0]], icon: ARCH[p[0]].icon };
        }),
        open: function () {
          self.openAgent(x.a.id, s.arch === "all" ? 0 : Math.max(0, x.a.aids.indexOf(x.a.id + ":" + s.arch)));
        },
      };
    });
    var focus = [
      ["all", "Everything", "dot none"],
      ["gap", "Has gaps", "dot gap"],
      ["pending", "Has pending", "dot pending"],
      ["review", "In review", "dot review"],
    ].map(function (f) {
      return {
        label: f[1],
        dot: f[2],
        on: s.focus === f[0],
        cls: s.focus === f[0] ? "chip on" : "chip",
        pick: function () {
          self.setState({ focus: f[0] });
        },
      };
    });

    // agent page
    var b = this.counts(s, pm, [aid]),
      lists = { gap: [], pending: [], ok: [], na: [] },
      rev = [];
    var propVm = function (p) {
      return {
        name: self.reqName(p.aid, p.rid),
        fromPill: pillOf(p.from),
        fromLabel: ST[p.from].label,
        toPill: pillOf(p.to),
        toLabel: ST[p.to].label,
        source: p.source,
        reason: p.reason,
        evidence: p.evidence,
        open: function () {
          self.openReq(p.aid, p.rid);
        },
        accept: function () {
          self.decide(p.id, true);
        },
        dismiss: function () {
          self.decide(p.id, false);
        },
      };
    };
    REQS.forEach(function (r) {
      var bk = self.bucket(s, pm, aid, r.id),
        k = self.code(s, aid, r.id);
      if (bk === "review") {
        rev.push(propVm(pm[aid + ":" + r.id]));
        return;
      }
      var rq = self.reqFor(s, aid, r.id),
        note =
          rq && rq.status !== "closed"
            ? rq.status === "draft"
              ? "You drafted a question. Not sent yet."
              : rq.status === "waiting"
                ? "Asked the " + rq.team + ". Waiting for a reply."
                : ""
            : "";
      lists[bk].push({
        name: self.reqName(aid, r.id),
        tag: DISC[r.di].name + (bk === "gap" ? ". " + ST[k].label : ""),
        hasNote: !!note,
        note: note,
        open: function () {
          self.openReq(aid, r.id);
        },
      });
    });
    var byD = DISC.map(function (dd) {
      return { name: dd.name.toLowerCase(), gap: 0, pending: 0, total: 0 };
    });
    REQS.forEach(function (r) {
      var bk = self.bucket(s, pm, aid, r.id);
      byD[r.di].total++;
      if (bk === "gap") {
        byD[r.di].gap++;
      }
      if (bk === "pending") {
        byD[r.di].pending++;
      }
    });
    var topG = byD.slice().sort(function (x, y) {
        return y.gap - x.gap;
      })[0],
      topP = byD.slice().sort(function (x, y) {
        return y.pending - x.pending;
      })[0],
      read = [];
    if (b.review) {
      read.push(b.review + (b.review === 1 ? " answer is" : " answers are") + " ready for your decision. Start there.");
    }
    if (b.gap) {
      read.push("Most gaps sit in " + topG.name + " (" + topG.gap + " of " + b.gap + ").");
    }
    if (b.pending) {
      read.push(
        topP.name.charAt(0).toUpperCase() +
          topP.name.slice(1) +
          " is the biggest unknown: " +
          topP.pending +
          " of " +
          topP.total +
          " unanswered.",
      );
    }
    if (b.pending + b.review === 61) {
      read = ["Nothing has been answered yet. Run me on this agent and the first answers will land in review."];
    }
    if (!read.length) {
      read = ["Every requirement has an answer and nothing is waiting for you."];
    }
    var owner = s.owner[ag.id] || "",
      dec = s.decisions[ag.id];
    var agv = {
      name: ag.name,
      ext: !!ag.ext,
      does: s.purpose[ag.id] || ag.does,
      b: b,
      readTitle: "SIGMA's read",
      read: read.join(" "),
      facts:
        (owner ? "Owned by " + owner : "Owner not confirmed") +
        ". Hosting: " +
        (ag.host || "not recorded") +
        ". " +
        (s.purpose[ag.id] ? "Description entered here." : "Description drafted by SIGMA, for the owner to confirm."),
      hasTabs: ag.aids.length > 1,
      tabs: ag.aids.map(function (a, i) {
        var c = self.counts(s, pm, [a]);
        return {
          name: ARCH[ASSESS[a].arch].name,
          icon: ARCH[ASSESS[a].arch].icon,
          line: c.gap + " gaps, " + c.pending + " pending, " + c.review + " in review",
          on: i === aIdx,
          cls: i === aIdx ? "tab on" : "tab",
          pick: function () {
            self.setState({ aIdx: i, okOpen: false, naOpen: false });
          },
        };
      }),
      archName: M.name,
      archIcon: M.icon,
      archDoes: M.does + ' Called "' + M.deck + '" in the deck, slide ' + M.slides + ".",
      gaps: lists.gap,
      pend: lists.pending,
      rev: rev,
      noGaps: !lists.gap.length,
      noPend: !lists.pending.length,
      noRev: !rev.length,
      okOpen: s.okOpen,
      naOpen: s.naOpen,
      okList: lists.ok,
      naList: lists.na,
      toggleOk: function () {
        self.setState({ okOpen: !s.okOpen });
      },
      toggleNa: function () {
        self.setState({ naOpen: !s.naOpen });
      },
      okLabel: b.ok + " in place",
      okHint: s.okOpen ? "Hide" : "Stated in the deck or reviewed here. Show them",
      naLabel: b.na + " not applicable",
      naHint: s.naOpen ? "Hide" : "Show them",
      editDetails: function () {
        self.setState({ drawer: "details" });
      },
      openReview: function () {
        self.setState({ drawer: "review" });
      },
      reviewLabel: dec ? "Outcome: " + dec.outcome : "Record review outcome",
    };

    // requirement drawer
    var R = REQS[RIDX[s.sel]] || REQS[0],
      k = this.code(s, aid, R.id),
      ov = s.ans[aid + ":" + R.id],
      pp = pm[aid + ":" + R.id],
      cur = this.reqFor(s, aid, R.id);
    var d = {
      id: R.id,
      name: this.reqName(aid, R.id),
      disc: DISC[R.di].name,
      scope: ag.name + ", " + M.name.toLowerCase(),
      label: ST[k].label,
      long: ST[k].long,
      code: k,
      pill: pillOf(k),
      guide: R.guide,
      origin: ov
        ? ov.origin === "manual"
          ? "Recorded here by you on 17 Sep 2026."
          : "Reviewed and accepted here on 17 Sep 2026."
        : k === "TBD"
          ? "No answer has been recorded."
          : "From the deck, slide " + M.slides + ". Historical: not yet verified in this workspace.",
      hasRaw: !ov && !!RAW[aid + ":" + R.id],
      raw: RAW[aid + ":" + R.id] || "",
      hasOthers: ag.aids.length > 1,
      others: ag.aids
        .filter(function (a) {
          return a !== aid;
        })
        .map(function (a) {
          var ko = self.code(s, a, R.id);
          return {
            arch: ARCH[ASSESS[a].arch].name,
            label: ST[ko].label + (ko !== k ? ". Different from this assessment." : ". Same as this assessment."),
            dot: "dot " + self.bucket(s, pm, a, R.id),
            open: function () {
              self.openReq(a, R.id);
            },
          };
        }),
      hasEvidence: !!ov || k !== "TBD",
      evidence: ov
        ? ov.evidence
        : [
            {
              label: "Deck baseline",
              detail: "Agentic AI Security Status Updates v2, slide " + M.slides + ". A statement from the deck, not a tested control.",
            },
          ],
      hasProp: !!pp,
      prop: pp ? propVm(pp) : { fromPill: "pill", toPill: "pill" },
      canAsk: !cur || cur.status === "closed",
      askLabel: "Ask the " + DISC[R.di].team,
      ask: function () {
        self.askTeam(aid, R.id);
      },
      recLabel: s.recOpen ? "Cancel" : "Record an answer yourself",
      toggleRec: function () {
        self.setState({ recOpen: !s.recOpen, recErr: "" });
      },
      recOpen: s.recOpen,
      rec: s.rec,
      hasRecErr: !!s.recErr,
      recErr: s.recErr,
      onRecStatus: function (e) {
        self.setState({ rec: Object.assign({}, s.rec, { status: e.target.value }) });
      },
      onRecEv: function (e) {
        self.setState({ rec: Object.assign({}, s.rec, { evidence: e.target.value }) });
      },
      onRecNote: function (e) {
        self.setState({ rec: Object.assign({}, s.rec, { note: e.target.value }) });
      },
      saveRec: function () {
        self.saveRec(aid, R.id);
      },
      askSigma: function () {
        self.send("Draft a question about " + R.id);
      },
    };
    var th = cur
      ? {
          has: true,
          team: cur.team,
          status: RSTATUS[cur.status],
          pill: RPILL[cur.status],
          messages: cur.messages.map(function (mm) {
            return { who: mm.who, at: mm.at, text: mm.text, cls: mm.dir === "in" ? "msg in" : "msg out" };
          }),
          isDraft: cur.status === "draft",
          showReplyBtn: cur.status === "waiting" && !s.replyOpen,
          replyOpen: cur.status === "waiting" && s.replyOpen,
          reply: s.reply,
          hasReplyErr: !!s.replyErr,
          replyErr: s.replyErr,
          canClose: cur.status === "answered" && !pp,
          queue: function () {
            self.queue(cur.id);
          },
          toggleReply: function () {
            self.toggleReply(cur.id);
          },
          saveReply: function () {
            self.saveReply(cur.id);
          },
          close: function () {
            self.closeReq(cur.id);
          },
          onReplyText: function (e) {
            self.setState({ reply: Object.assign({}, s.reply, { text: e.target.value }) });
          },
          onReplyStatus: function (e) {
            self.setState({ reply: Object.assign({}, s.reply, { status: e.target.value }) });
          },
          onReplyEv: function (e) {
            self.setState({ reply: Object.assign({}, s.reply, { evidence: e.target.value }) });
          },
        }
      : { has: false, messages: [], reply: s.reply };

    // details and review drawers
    var dt = {
      does: s.purpose[ag.id] != null ? s.purpose[ag.id] : ag.does,
      owner: owner,
      missing:
        joinList(
          [owner ? "" : "responsible team", "environment", ag.host ? "" : "hosting", "architecture evidence"].filter(function (x) {
            return x;
          }),
        ) + ".",
      onDoes: function (e) {
        var p = Object.assign({}, s.purpose);
        p[ag.id] = e.target.value;
        self.setState({ purpose: p });
      },
      onOwner: function (e) {
        var o = Object.assign({}, s.owner);
        o[ag.id] = e.target.value;
        self.setState({ owner: o });
      },
    };
    var allB = this.counts(s, pm, ag.aids),
      openWork = ag.aids.map(function (a) {
        var c = self.counts(s, pm, [a]);
        return { text: ARCH[ASSESS[a].arch].name + ": " + c.gap + " gaps, " + c.pending + " pending, " + c.review + " in review." };
      });
    var openRq = s.requests.filter(function (r) {
      return ASSESS[r.aid].agent === ag.id && r.status !== "closed";
    }).length;
    if (openRq) {
      openWork.push({ text: openRq + (openRq > 1 ? " conversations with teams are" : " conversation with a team is") + " still open." });
    }
    if (!owner) {
      openWork.push({ text: "The responsible team is not confirmed." });
    }
    var pick = function (o) {
      return function () {
        self.setState({ outcome: o, rvErr: "" });
      };
    };
    var rv = {
      open: openWork,
      noDecision: !dec,
      hasDecision: !!dec,
      decision: dec || { reviewer: "", outcome: "", note: "" },
      o1: s.outcome === "changes" ? "radio on" : "radio",
      o2: s.outcome === "conditions" ? "radio on" : "radio",
      o3: s.outcome === "complete" ? "radio on" : "radio",
      p1: s.outcome === "changes",
      p2: s.outcome === "conditions",
      p3: s.outcome === "complete",
      pick1: pick("changes"),
      pick2: pick("conditions"),
      pick3: pick("complete"),
      reviewer: s.reviewer,
      note: s.note,
      onReviewer: set("reviewer"),
      onNote: set("note"),
      hasErr: !!s.rvErr,
      err: s.rvErr,
      reportTitle: s.reportTitle || ag.name + " security review, 17 Sep 2026",
      onReportTitle: set("reportTitle"),
      record: function () {
        if (!s.outcome || !s.reviewer.trim() || !s.note.trim()) {
          self.setState({ rvErr: "Choose an outcome, add your name and give the reason." });
          return;
        }
        var dd = Object.assign({}, s.decisions);
        dd[ag.id] = { outcome: OUTCOMES[s.outcome], reviewer: s.reviewer.trim(), note: s.note.trim() };
        self.say({ decisions: dd, rvErr: "" }, "Outcome recorded for " + ag.name + ": " + OUTCOMES[s.outcome] + ".");
      },
      saveReport: function () {
        var rep = {
          title: s.reportTitle || ag.name + " security review, 17 Sep 2026",
          meta: ag.name + ", saved 17 Sep 2026 by " + dec.reviewer,
          outcome: dec.outcome,
          note: dec.note,
          b: allB,
          line:
            "When saved: " +
            allB.gap +
            " gaps, " +
            allB.pending +
            " pending, " +
            allB.review +
            " in review, " +
            allB.ok +
            " in place and " +
            allB.na +
            " not applicable, across " +
            ag.aids.length +
            (ag.aids.length > 1 ? " assessments." : " assessment."),
        };
        self.say(
          { reports: [rep].concat(s.reports), view: "reports", drawer: "", reportTitle: "" },
          "Report saved. It keeps these answers even if the agent changes.",
        );
      },
    };

    // requests
    var rqGroups = [
      ["answered", "Answered", "A reply came in. Decide on the new answer."],
      ["draft", "Drafts", "Written, not sent yet."],
      ["waiting", "Waiting for a reply", "With the team."],
      ["closed", "Closed", ""],
    ]
      .map(function (g) {
        return {
          label: g[1],
          hint: g[2],
          pill: RPILL[g[0]],
          items: s.requests
            .filter(function (r) {
              return r.status === g[0];
            })
            .map(function (r) {
              return {
                title: r.title,
                sub: AGENT[ASSESS[r.aid].agent].name + ", " + ARCH[ASSESS[r.aid].arch].name.toLowerCase() + ", " + r.rid,
                team: r.team,
                open: function () {
                  self.openReq(r.aid, r.rid);
                },
              };
            }),
        };
      })
      .filter(function (g) {
        return g.items.length > 0;
      });
    var needYou = s.requests.filter(function (r) {
      return r.status === "draft" || r.status === "answered";
    }).length;

    // assistant
    var inDrawer = view === "agent" && s.drawer === "req";
    var ctxLabel =
      view === "agent"
        ? ag.name + ", " + M.name.toLowerCase() + (inDrawer ? ", " + R.id : "")
        : view === "requests"
          ? "requests"
          : view === "reports"
            ? "reports"
            : s.arch === "all"
              ? "all agents"
              : ARCH[s.arch].name.toLowerCase();
    var pr = inDrawer
      ? ["Draft a question about " + R.id, "What does " + k + " mean?"]
      : view === "agent"
        ? ["Run SIGMA on this agent", "What should I do next?", ag.aids.length > 1 ? "Compare its assessments" : "What is pending here?"]
        : view === "reports"
          ? ["Summarise the workspace for leadership"]
          : view === "requests"
            ? ["What should I do next?", "What is waiting for review?"]
            : ["Run SIGMA across the workspace", "Which agents have the most gaps?", "Show only multi-agent workflows"];
    var chat = s.chat
      .slice()
      .reverse()
      .map(function (m) {
        return {
          wrap: m.who === "user" ? "wrap-user" : "wrap-sigma",
          bubble: m.who === "user" ? "bub-user" : "bub-sigma",
          text: m.text,
          hasItems: !!(m.items && m.items.length),
          items: (m.items || []).map(function (it) {
            return {
              label: it.label,
              sub: it.sub,
              dot: it.bucket ? "dot " + it.bucket : "dot none",
              run: function () {
                self.act(it.act);
              },
            };
          }),
          hasActions: !!(m.actions && m.actions.length),
          actions: (m.actions || []).map(function (a) {
            return {
              label: a.label,
              cls: a.pri ? "btn pri sm" : "btn sm",
              run: function () {
                self.act(a);
              },
            };
          }),
          hasLink: !!m.link,
          hasBasis: !!m.basis,
          basis: m.basis || "",
        };
      });
    var rn = s.run,
      running = rn.status === "running",
      idle = rn.status === "idle";
    var runv = {
      stages: STAGES.map(function (st, i) {
        var done = idle || rn.status === "done" || rn.stage > i,
          act = running && rn.stage === i;
        return {
          label: st[0],
          sub: idle ? LAST[i] : done ? rn.res[i] || "done" : act ? "working" : "queued",
          node: "stg" + (done ? " done" : act ? " run" : ""),
          mark: done ? "\u2713" : "" + (i + 1),
          l: i === 0 ? "ln hide" : done || act ? "ln on" : "ln",
          r: i === 5 ? "ln hide" : done ? "ln on" : "ln",
        };
      }),
      title: running ? "SIGMA is working: " + STAGES[rn.stage][0].toLowerCase() : idle ? "SIGMA is idle" : "SIGMA finished",
      line: running
        ? STAGES[rn.stage][1] + (rn.scope === "all" ? "." : " for " + AGENT[rn.scope].name + ".")
        : idle
          ? "Last run 16 Sep. It read 33 agent records, left 10 answers in review and drafted 3 questions."
          : rn.summary,
      state: running ? "Working" : "Idle",
      busy: running,
      btnAll: running ? "Running" : "Run SIGMA",
      btnAgent: running ? "Running" : "Run SIGMA on this agent",
      fab: running ? "SIGMA is working" : "Ask SIGMA",
      orb: running ? "orb run" : "orb",
      orbSm: running ? "orb sm run" : "orb sm",
      onAgent: !idle && rn.scope === ag.id,
      startAll: function () {
        self.startRun("all");
      },
      startAgent: function () {
        self.startRun(ag.id);
      },
    };
    var logv = s.log
      .slice()
      .reverse()
      .map(function (l) {
        return { at: l.at, stage: l.stage, text: l.text, cls: l.head ? "logl head" : "logl" };
      });
    var go = function (v) {
      return function () {
        self.setState({ view: v, drawer: "" });
      };
    };
    return {
      themeCls: this.props.theme === "light" ? "app theme-light" : "app",
      run: runv,
      log: logv,
      tabChat: s.tab !== "act",
      tabAct: s.tab === "act",
      tabChatCls: s.tab !== "act" ? "seg2 on" : "seg2",
      tabActCls: s.tab === "act" ? "seg2 on" : "seg2",
      pickChat: function () {
        self.setState({ tab: "chat" });
      },
      pickAct: function () {
        self.setState({ tab: "act" });
      },
      isHome: view === "home",
      isAgent: view === "agent",
      isRequests: view === "requests",
      isReports: view === "reports",
      navAgents: view === "home" || view === "agent" ? "nav on" : "nav",
      navRequests: view === "requests" ? "nav on" : "nav",
      navReports: view === "reports" ? "nav on" : "nav",
      goHome: go("home"),
      goRequests: go("requests"),
      goReports: go("reports"),
      requestCount: needYou,
      addAgent: function () {
        self.send("Add an agent");
      },
      rail: rail,
      home: home,
      agents: agents,
      noAgents: agents.length === 0,
      focus: focus,
      q: s.q,
      onQ: set("q"),
      sortLabel: s.sort === "name" ? "Sorted A to Z" : "Sorted by what needs you",
      toggleSort: function () {
        self.setState({ sort: s.sort === "name" ? "attention" : "name" });
      },
      ag: agv,
      d: d,
      th: th,
      dt: dt,
      rv: rv,
      drawerOpen: view === "agent" && !!s.drawer,
      isReqDrawer: s.drawer === "req",
      isDetailsDrawer: s.drawer === "details",
      isReviewDrawer: s.drawer === "review",
      closeDrawer: function () {
        self.setState({ drawer: "", recOpen: false, replyOpen: false });
      },
      rqGroups: rqGroups,
      reports: s.reports,
      noReports: s.reports.length === 0,
      goReviewEm: function () {
        self.setState({ view: "agent", agentId: "em", aIdx: 0, drawer: "review" });
      },
      asstOpen: asstOpen,
      asstClosed: !asstOpen,
      toggleAsst: function () {
        self.setState({ asstOpen: !asstOpen });
      },
      ctxLabel: ctxLabel,
      chat: chat,
      thinking: s.thinking,
      prompts: pr.map(function (p) {
        return {
          text: p,
          run: function () {
            self.send(p);
          },
        };
      }),
      draft: s.draft,
      onDraft: set("draft"),
      onChatKey: function (e) {
        if (e.key === "Enter") {
          self.send();
        }
      },
      sendDraft: function () {
        self.send();
      },
      hasToast: !!s.toast,
      toast: s.toast,
    };
  }

  render() {
    const v = this.renderVals();
    return (
      <div className="sigma-main">
        <div
          className={v.themeCls}
          style={{
            position: "relative",
            width: "100%",
            height: "100vh",
            minHeight: "760px",
            display: "flex",
            overflow: "hidden",
            background: "var(--bg)",
            color: "var(--text)",
            fontSize: "15px",
            lineHeight: "1.45",
          }}
        >
          <aside
            aria-label="Navigation"
            style={{
              width: "240px",
              flexShrink: "0",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              background: "var(--bg2)",
              borderRight: "1px solid var(--line)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "11px", padding: "20px 18px 16px" }}>
              <span className="logo">
                <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
                  <path
                    d="M13.5 4H5l4.6 5L5 14h8.5"
                    fill="none"
                    stroke="#FFFFFF"
                    strokeWidth="2.3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
              <span style={{ fontSize: "19px", fontWeight: "700", letterSpacing: "0.06em" }}>SIGMA</span>
            </div>
            <nav aria-label="Main" style={{ display: "flex", flexDirection: "column", gap: "2px", padding: "0 10px" }}>
              <button className={v.navAgents} onClick={v.goHome}>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 20 20"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.7"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M10 2.5l6.5 3.75v7.5L10 17.5l-6.5-3.75v-7.5zM10 7.8a2.2 2.2 0 1 0 0 4.4 2.2 2.2 0 0 0 0-4.4z" />
                </svg>
                <span style={{ flexGrow: "1" }}>Agents</span>
              </button>
              <button className={v.navRequests} onClick={v.goRequests}>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 20 20"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.7"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M3.5 5.5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H9l-3.5 3v-3a2 2 0 0 1-2-2z" />
                </svg>
                <span style={{ flexGrow: "1" }}>Requests</span>
                <span className="count">{v.requestCount}</span>
              </button>
              <button className={v.navReports} onClick={v.goReports}>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 20 20"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.7"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  aria-hidden="true"
                >
                  <path d="M5.5 2.5h6l3 3v12h-9zM8 9.5h4M8 12.5h4" />
                </svg>
                <span style={{ flexGrow: "1" }}>Reports</span>
              </button>
            </nav>
            <span className="sub" style={{ fontSize: "12px", fontWeight: "600", letterSpacing: "0.02em", padding: "22px 22px 8px" }}>
              Archetypes
            </span>
            <div
              style={{
                flexGrow: "1",
                minHeight: "0",
                overflowY: "auto",
                padding: "0 10px 12px",
                display: "flex",
                flexDirection: "column",
                gap: "2px",
              }}
            >
              {(v.rail || []).map((r, rIndex) => (
                <React.Fragment key={rIndex}>
                  <button className={r.cls} aria-pressed={r.on} onClick={r.pick}>
                    <span style={{ display: "flex", alignItems: "center", gap: "9px" }}>
                      <svg
                        width="17"
                        height="17"
                        viewBox="0 0 20 20"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.7"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                      >
                        <path d={r.icon} />
                      </svg>
                      <span style={{ flexGrow: "1", fontWeight: "600", fontSize: "13.5px" }}>{r.name}</span>
                      <span className="mono" style={{ fontSize: "12px" }}>
                        {r.count}
                      </span>
                    </span>
                    <span className="bar thin">
                      <span className="seg gap" style={{ flex: `${r.b?.gap} 1 0px` }} />
                      <span className="seg pending" style={{ flex: `${r.b?.pending} 1 0px` }} />
                      <span className="seg review" style={{ flex: `${r.b?.review} 1 0px` }} />
                      <span className="seg ok" style={{ flex: `${r.b?.ok} 1 0px` }} />
                      <span className="seg na" style={{ flex: `${r.b?.na} 1 0px` }} />
                    </span>
                  </button>
                </React.Fragment>
              ))}
            </div>
            <p className="sub" style={{ fontSize: "12px", padding: "12px 18px 16px", borderTop: "1px solid var(--line)" }}>
              Sample workspace. Answers from the deck are history, not verification.
            </p>
          </aside>
          <div
            style={{ position: "relative", flexGrow: "1", minWidth: "0", height: "100%", overflow: "hidden", background: "var(--aura)" }}
          >
            {v.isHome ? <HomeScreen v={v} /> : null}
            {v.isAgent ? <AgentScreen v={v} /> : null}
            {v.isRequests ? <RequestsScreen v={v} /> : null}
            {v.isReports ? <ReportsScreen v={v} /> : null}
          </div>
          {v.asstOpen ? <AssistantPanel v={v} /> : null}
          {v.asstClosed ? (
            <>
              <button
                aria-label="Open SIGMA"
                onClick={v.toggleAsst}
                style={{
                  position: "absolute",
                  right: "22px",
                  bottom: "22px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  height: "52px",
                  padding: "0 20px 0 8px",
                  borderRadius: "26px",
                  border: "0",
                  background: "var(--agentBtn)",
                  color: "#FFFFFF",
                  fontWeight: "600",
                  boxShadow: "0 12px 40px var(--glow)",
                  zIndex: "8",
                }}
              >
                <span
                  style={{
                    width: "36px",
                    height: "36px",
                    borderRadius: "50%",
                    background: "rgba(255, 255, 255, 0.18)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <svg width="16" height="16" viewBox="0 0 18 18" aria-hidden="true">
                    <path
                      d="M13.5 4H5l4.6 5L5 14h8.5"
                      fill="none"
                      stroke="#FFFFFF"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
                <span>{v.run?.fab}</span>
              </button>
            </>
          ) : null}
          {v.hasToast ? (
            <>
              <div className="toast" role="status">
                {v.toast}
              </div>
            </>
          ) : null}
        </div>
      </div>
    );
  }
}

SigmaApp.defaultProps = { startScreen: "agents", assistantOpen: true, theme: "dark" };
